from flask import Flask, render_template, request, jsonify, send_file, session
import google.generativeai as genai
import os
from dotenv import load_dotenv
import json
from datetime import datetime
import random
from instagrapi import Client
from instagrapi.exceptions import LoginRequired, BadPassword, ChallengeRequired, TwoFactorRequired
import base64
from PIL import Image
import io
import traceback
import sys
from openai import OpenAI
from huggingface_hub import InferenceClient

# تحميل المتغيرات البيئية
load_dotenv()

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.secret_key = os.urandom(24)

# تكوين OpenAI وفقاً للتوثيق الرسمي
client = OpenAI(
    api_key=os.getenv('OPENAI_API_KEY')
)

# تكوين Gemini
api_key = os.getenv('GOOGLE_API_KEY')
print(f"Using API key: {api_key[:8]}...", file=sys.stderr)
genai.configure(api_key=api_key)
text_model = genai.GenerativeModel('gemini-pro')
vision_model = genai.GenerativeModel('gemini-pro-vision')

# Initialize Instagram client
instagram_client = None

def init_instagram_client():
    try:
        client = Client()
        client.login(os.getenv('INSTAGRAM_USERNAME'), os.getenv('INSTAGRAM_PASSWORD'))
        return client
    except Exception as e:
        print(f"Error initializing Instagram client: {str(e)}", file=sys.stderr)
        return None

# قاعدة بيانات بسيطة للنصائح والأفكار
CONTENT_TIPS = {
    'instagram_post': [
        'استخدم صور عالية الجودة',
        'اكتب كابشن يثير المشاعر',
        'استخدم 5-10 هاشتاغات',
        'اطرح سؤالاً في نهاية المنشور',
    ],
    'instagram_story': [
        'استخدم الملصقات التفاعلية',
        'أضف موسيقى مناسبة',
        'استخدم استطلاعات الرأي',
        'اربط القصة بمنشور في حسابك',
    ],
    'instagram_reel': [
        'استخدم موسيقى رائجة',
        'اجعل أول 3 ثواني مثيرة',
        'أضف نصوصاً على الفيديو',
        'استخدم الترندات الحالية',
    ],
    'tiktok': [
        'تابع التحديات الشائعة',
        'استخدم الفلاتر المميزة',
        'شارك في الترندات',
        'أضف موسيقى من قائمة الأكثر استخداماً',
    ]
}

BEST_POSTING_TIMES = {
    'instagram_post': ['9:00 صباحاً', '3:00 مساءً', '9:00 مساءً'],
    'instagram_story': ['8:00 صباحاً', '2:00 مساءً', '8:00 مساءً'],
    'instagram_reel': ['11:00 صباحاً', '5:00 مساءً', '10:00 مساءً'],
    'tiktok': ['10:00 صباحاً', '4:00 مساءً', '11:00 مساءً']
}

# بيانات الجمهور المستهدف
TARGET_AUDIENCE_DATA = {
    'عام': 'محتوى يناسب جميع الفئات العمرية والاهتمامات.',
    'شباب': 'محتوى حيوي يتماشى مع اهتمامات الشباب وأحدث الترندات.',
    'عائلات': 'محتوى يركز على القيم العائلية والأنشطة الجماعية.',
    'رجال أعمال': 'محتوى احترافي يركز على الابتكار والنمو المهني.',
    'طلاب': 'محتوى تعليمي وترفيهي يناسب الطلاب.'
}

def generate_image_prompt(topic):
    prompt = f"""اقترح وصفاً لصورة تناسب المنشور التالي على Instagram:
    الموضوع: {topic}
    نوع النشاط: 
    
    اكتب الوصف باللغة العربية، وركز على العناصر البصرية والتكوين والألوان."""
    
    response = text_model.generate_content(prompt)
    return response.text

def format_content_for_instagram(content):
    # تنسيق المحتوى للنشر على انستغرام
    formatted_content = {
        'caption': '',
        'hashtags': []
    }
    
    try:
        # استخراج النص الرئيسي والهاشتاغات
        lines = content.split('\n')
        caption_lines = []
        hashtags = []
        
        for line in lines:
            if line.strip().startswith('#'):
                # جمع الهاشتاغات
                tags = line.strip().split()
                hashtags.extend(tags)
            else:
                # جمع النص
                if line.strip():
                    caption_lines.append(line.strip())
        
        # تنسيق النص النهائي
        formatted_content['caption'] = '\n\n'.join(caption_lines)
        if hashtags:
            formatted_content['caption'] += '\n\n' + ' '.join(hashtags)
        formatted_content['hashtags'] = hashtags
        
    except Exception as e:
        print(f"Error formatting content: {str(e)}", file=sys.stderr)
        print("Detailed error:")
        print(traceback.format_exc(), file=sys.stderr)
        formatted_content['caption'] = content
    
    return formatted_content

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_tips', methods=['POST'])
def get_tips():
    try:
        data = request.get_json()
        content_type = data.get('contentType', '')
        
        if content_type in CONTENT_TIPS:
            return jsonify({
                'success': True,
                'tips': random.sample(CONTENT_TIPS[content_type], 2),
                'best_times': random.sample(BEST_POSTING_TIMES[content_type], 2)
            })
        
        return jsonify({
            'success': False,
            'error': 'نوع المحتوى غير معروف'
        })
    
    except Exception as e:
        print(f"Error getting tips: {str(e)}", file=sys.stderr)
        print("Detailed error:")
        print(traceback.format_exc(), file=sys.stderr)
        return jsonify({
            'success': False,
            'error': 'حدث خطأ في جلب النصائح'
        })

@app.route('/generate_content', methods=['POST'])
def generate_content():
    try:
        print("=== بداية توليد المحتوى ===", file=sys.stderr)
        data = request.get_json()
        topic = data.get('topic', '')
        business_type = data.get('business_type', '')
        content_type = data.get('content_type', 'tips')
        content_length = data.get('content_length', 'medium')
        add_hashtags = data.get('add_hashtags', True)
        tone = data.get('tone', '')
        
        print(f"الموضوع: {topic}", file=sys.stderr)
        print(f"نوع النشاط: {business_type}", file=sys.stderr)
        print(f"نمط المحتوى: {content_type}", file=sys.stderr)
        print(f"طول المحتوى: {content_length}", file=sys.stderr)
        print(f"النبرة: {tone}", file=sys.stderr)
        
        # تحديد طول المحتوى المطلوب
        length_limits = {
            'short': '100-150',
            'medium': '150-200',
            'long': '200-250'
        }
        char_limit = length_limits.get(content_length, '150-200')
        
        # تحديد نمط المحتوى
        content_styles = {
            'tips': 'نصائح ومعلومات مفيدة',
            'story': 'قصة قصيرة جذابة',
            'ad': 'محتوى إعلاني مقنع',
            'quote': 'اقتباس ملهم مع شرح مناسب'
        }
        style = content_styles.get(content_type, 'نصائح ومعلومات مفيدة')
        
        # توليد المحتوى النصي
        prompt = f"""أنت خبير في كتابة محتوى وسائل التواصل الاجتماعي باللغة العربية.
        قم بإنشاء محتوى جذاب لمنشور على Instagram حول الموضوع التالي:
        
        الموضوع: {topic}
        نوع النشاط: {business_type}
        نبرة المحتوى: {tone}
        نمط المحتوى: {style}
        طول المحتوى: {char_limit} حرف
        
        يجب أن يتضمن المحتوى:
        1. نصاً جذاباً باللغة العربية الفصحى
        2. {'هاشتاغات مناسبة باللغتين العربية والإنجليزية (5 هاشتاغات على الأقل)' if add_hashtags else 'بدون هاشتاغات'}
        3. دعوة للتفاعل باللغة العربية
        
        قم بتنسيق الرد بالضبط كما يلي:
        Caption: [النص الجذاب هنا]
        Call to Action: [دعوة للتفاعل هنا]
        {'Hashtags: [الهاشتاغات هنا]' if add_hashtags else ''}

        ملاحظات مهمة:
        - اكتب النص باللغة العربية فقط
        - تأكد من أن النص يتناسب مع نبرة المحتوى المطلوبة
        - اجعل دعوة التفاعل محفزة ومناسبة للموضوع
        {'- استخدم مزيجاً من الهاشتاغات العربية والإنجليزية' if add_hashtags else ''}"""
        
        print("إرسال الطلب إلى النموذج...", file=sys.stderr)
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        
        if not response:
            raise Exception("لم يتم استلام رد من النموذج")
            
        content = response.text
        print("تم استلام المحتوى بنجاح", file=sys.stderr)
        print(f"المحتوى المستلم: {content}", file=sys.stderr)
        
        # Parse the content
        sections = content.split('\n')
        formatted_content = {
            'caption': '',
            'hashtags': [],
            'call_to_action': ''
        }
        
        current_section = None
        for line in sections:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('Caption:'):
                current_section = 'caption'
                formatted_content['caption'] = line.replace('Caption:', '').strip()
            elif line.startswith('Call to Action:'):
                current_section = 'call_to_action'
                formatted_content['call_to_action'] = line.replace('Call to Action:', '').strip()
            elif line.startswith('Hashtags:'):
                current_section = 'hashtags'
                hashtags = line.replace('Hashtags:', '').strip()
                formatted_content['hashtags'] = [tag.strip() for tag in hashtags.split() if tag.strip()]
            elif current_section:
                # Append content to the current section
                if current_section == 'hashtags':
                    formatted_content['hashtags'].extend([tag.strip() for tag in line.split() if tag.strip()])
                else:
                    formatted_content[current_section] += '\n' + line
        
        # Clean up the content
        formatted_content['caption'] = formatted_content['caption'].strip()
        formatted_content['call_to_action'] = formatted_content['call_to_action'].strip()
        
        # توليد وصف الصورة
        image_prompt = f"""اقترح وصفاً لصورة تناسب المنشور التالي على Instagram:
        الموضوع: {topic}
        نوع النشاط: {business_type}
        
        اكتب الوصف باللغة العربية، وركز على العناصر البصرية والتكوين والألوان."""
        
        image_response = model.generate_content(image_prompt)
        image_description = image_response.text if image_response else ""
        
        print("تم توليد وصف الصورة", file=sys.stderr)
        
        return jsonify({
            'success': True,
            'content': formatted_content,
            'image_prompt': image_description
        })
        
    except Exception as e:
        print(f"خطأ في توليد المحتوى: {str(e)}", file=sys.stderr)
        print("تفاصيل الخطأ:")
        print(traceback.format_exc(), file=sys.stderr)
        return jsonify({
            'success': False,
            'error': str(e) or 'حدث خطأ في توليد المحتوى'
        })

@app.route('/post_to_instagram', methods=['POST'])
def post_to_instagram():
    try:
        data = request.get_json()
        caption = data.get('caption', '')
        image_data = data.get('image', '')  # Base64 encoded image
        
        # تنظيف النص
        clean_caption = caption.replace('<div>', '').replace('</div>', '\n').replace('<br>', '\n')
        
        # حفظ الصورة مؤقتاً
        if image_data:
            try:
                # تحويل Base64 إلى صورة
                image_bytes = base64.b64decode(image_data.split(',')[1])
                image = Image.open(io.BytesIO(image_bytes))
                
                # حفظ الصورة مؤقتاً
                with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_file:
                    image.save(temp_file.name, 'JPEG')
                    
                    # نشر الصورة على انستغرام
                    cl = Client()
                    cl.login(session['instagram_username'], session['instagram_password'])
                    media = cl.photo_upload(
                        temp_file.name,
                        caption=clean_caption
                    )
                
                # حذف الملف المؤقت
                os.unlink(temp_file.name)
                
                return jsonify({
                    'success': True,
                    'message': 'تم نشر المحتوى بنجاح'
                })
                
            except Exception as e:
                print(f"Error processing image: {str(e)}", file=sys.stderr)
                print("Detailed error:")
                print(traceback.format_exc(), file=sys.stderr)
                return jsonify({
                    'success': False,
                    'error': f'خطأ في معالجة الصورة: {str(e)}'
                })
        else:
            # إرسال رسالة مباشرة فقط
            cl = Client()
            cl.login(session['instagram_username'], session['instagram_password'])
            user_id = cl.user_id
            cl.direct_send(clean_caption, [user_id])
            
            return jsonify({
                'success': True,
                'message': 'تم إرسال النص بنجاح'
            })
            
    except Exception as e:
        print(f"Error posting to Instagram: {str(e)}", file=sys.stderr)
        print("Detailed error:")
        print(traceback.format_exc(), file=sys.stderr)
        return jsonify({
            'error': str(e)
        }), 500

@app.route('/connect_instagram', methods=['POST'])
def connect_instagram():
    try:
        print("=== بداية الاتصال بالانستجرام ===", file=sys.stderr)
        username = os.getenv('INSTAGRAM_USERNAME')
        password = os.getenv('INSTAGRAM_PASSWORD')

        if not username or not password:
            print("خطأ: بيانات الاعتماد غير موجودة في ملف .env", file=sys.stderr)
            return jsonify({
                'success': False,
                'error': 'بيانات الاعتماد غير موجودة'
            }), 400

        try:
            # تهيئة كائن Instagram
            cl = Client()
            cl.delay_range = [1, 3]
            cl.request_timeout = 30
            
            try:
                # محاولة تسجيل الدخول
                print("محاولة تسجيل الدخول...", file=sys.stderr)
                login_result = cl.login(username, password)
                print(f"نتيجة تسجيل الدخول: {login_result}", file=sys.stderr)
                
                if login_result:
                    print("تم تسجيل الدخول بنجاح", file=sys.stderr)
                    session['instagram_username'] = username
                    session['instagram_connected'] = True
                    session['instagram_session'] = cl.get_settings()
                    return jsonify({'success': True})
                else:
                    print("فشل تسجيل الدخول: لم يتم إرجاع نتيجة صحيحة", file=sys.stderr)
                    return jsonify({
                        'success': False,
                        'error': 'فشل تسجيل الدخول'
                    }), 401
                    
            except Exception as e:
                error_type = type(e).__name__
                error_message = str(e)
                print(f"خطأ في تسجيل الدخول: {error_type} - {error_message}", file=sys.stderr)
                print(traceback.format_exc(), file=sys.stderr)
                
                if isinstance(e, BadPassword):
                    return jsonify({
                        'success': False,
                        'error': 'كلمة المرور غير صحيحة'
                    }), 401
                elif isinstance(e, ChallengeRequired):
                    print("مطلوب رمز تحقق", file=sys.stderr)
                    return jsonify({
                        'success': False,
                        'error': 'challenge_required'
                    }), 403
                elif isinstance(e, TwoFactorRequired):
                    return jsonify({
                        'success': False,
                        'error': 'التحقق بخطوتين مفعل. يرجى تعطيله مؤقتاً'
                    }), 403
                else:
                    return jsonify({
                        'success': False,
                        'error': f'حدث خطأ: {error_message}'
                    }), 500
                    
        except Exception as e:
            print(f"خطأ غير متوقع: {type(e).__name__} - {str(e)}", file=sys.stderr)
            print(traceback.format_exc(), file=sys.stderr)
            return jsonify({
                'success': False,
                'error': 'حدث خطأ في الاتصال'
            }), 500
            
    except Exception as e:
        print(f"خطأ غير متوقع: {type(e).__name__} - {str(e)}", file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return jsonify({
            'success': False,
            'error': 'حدث خطأ في الاتصال'
        }), 500

@app.route('/verify_instagram', methods=['POST'])
def verify_instagram():
    try:
        print("=== بداية التحقق من الرمز ===", file=sys.stderr)
        data = request.get_json()
        
        if not data:
            print("خطأ: لم يتم استلام بيانات JSON", file=sys.stderr)
            return jsonify({
                'success': False,
                'error': 'بيانات غير صالحة'
            }), 400

        verification_code = data.get('verification_code')
        username = os.getenv('INSTAGRAM_USERNAME')
        password = os.getenv('INSTAGRAM_PASSWORD')

        print(f"استخدام بيانات الاعتماد من ملف .env - username: {username}", file=sys.stderr)

        if not verification_code:
            print("خطأ: الرمز مفقود", file=sys.stderr)
            return jsonify({
                'success': False,
                'error': 'يرجى إدخال رمز التحقق'
            }), 400

        try:
            # تهيئة كائن Instagram
            cl = Client()
            cl.delay_range = [1, 3]
            cl.request_timeout = 30
            
            # تسجيل الدخول مع رمز التحقق
            print("محاولة تسجيل الدخول مع رمز التحقق...", file=sys.stderr)
            cl.login(username, password, verification_code=verification_code)
            print("تم تسجيل الدخول بنجاح!", file=sys.stderr)
            
            # حفظ معلومات الحساب في الجلسة
            session['instagram_username'] = username
            session['instagram_connected'] = True
            session['instagram_session'] = cl.get_settings()

            return jsonify({'success': True})
            
        except Exception as e:
            error_type = type(e).__name__
            error_message = str(e)
            print(f"خطأ في التحقق: {error_type} - {error_message}", file=sys.stderr)
            print(traceback.format_exc(), file=sys.stderr)
            
            if 'verification_code' in error_message.lower():
                return jsonify({
                    'success': False,
                    'error': 'رمز التحقق غير صحيح'
                }), 401
            else:
                return jsonify({
                    'success': False,
                    'error': 'حدث خطأ في عملية التحقق'
                }), 500
                
    except Exception as e:
        print(f"خطأ غير متوقع: {type(e).__name__} - {str(e)}", file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return jsonify({
            'success': False,
            'error': 'حدث خطأ في عملية التحقق'
        }), 500

@app.route('/get_account_info')
def get_account_info():
    try:
        if session.get('instagram_connected'):
            return jsonify({
                'success': True,
                'username': session.get('instagram_username')
            })
        return jsonify({'success': False})
    except Exception as e:
        print(f"خطأ في جلب معلومات الحساب: {str(e)}", file=sys.stderr)
        return jsonify({
            'success': False,
            'error': 'حدث خطأ في جلب معلومات الحساب'
        })

def save_to_history(content_data):
    history_file = 'content_history.json'
    try:
        if os.path.exists(history_file):
            with open(history_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
        else:
            history = []
        
        history.insert(0, content_data)
        history = history[:50]  # نحتفظ بآخر 50 محتوى فقط
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Error saving to history: {str(e)}", file=sys.stderr)
        print("Detailed error:")
        print(traceback.format_exc(), file=sys.stderr)

@app.route('/get_history', methods=['GET'])
def get_history():
    try:
        if os.path.exists('content_history.json'):
            with open('content_history.json', 'r', encoding='utf-8') as f:
                history = json.load(f)
            return jsonify({
                'success': True,
                'history': history[:10]  # نرجع آخر 10 محتويات فقط
            })
    except Exception as e:
        print(f"Error reading history: {str(e)}", file=sys.stderr)
        print("Detailed error:")
        print(traceback.format_exc(), file=sys.stderr)
    
    return jsonify({
        'success': False,
        'history': []
    })

@app.route('/generate_image', methods=['POST'])
def generate_image():
    try:
        print("=== بداية طلب توليد الصورة ===", file=sys.stderr)
        
        if not client:
            raise Exception("لم يتم تهيئة OpenAI بشكل صحيح. تحقق من مفتاح API")
            
        data = request.get_json()
        prompt = data.get('prompt', '')
        
        if not prompt:
            print("لم يتم توفير وصف للصورة", file=sys.stderr)
            return jsonify({
                'success': False,
                'error': 'لم يتم توفير وصف للصورة'
            })
        
        print(f"الوصف المستلم: {prompt}", file=sys.stderr)
        
        # تحويل الوصف إلى اللغة الإنجليزية للحصول على نتائج أفضل
        translation_prompt = f"""
        Translate the following image description to English, keeping the important details and making it more suitable for DALL-E image generation:
        {prompt}
        
        Translation:"""
        
        print("جاري ترجمة الوصف...", file=sys.stderr)
        translation_response = text_model.generate_content(translation_prompt)
        english_prompt = translation_response.text.strip()
        print(f"الوصف بالإنجليزية: {english_prompt}", file=sys.stderr)
        
        print("جاري إرسال الطلب إلى DALL-E...", file=sys.stderr)
        try:
            # توليد الصورة باستخدام DALL-E
            response = client.images.generate(
                model="dall-e-2",
                prompt=english_prompt,
                n=1,
                size="1024x1024"
            )
            
            image_url = response.data[0].url
            print(f"تم استلام رابط الصورة: {image_url}", file=sys.stderr)
            
            return jsonify({
                'success': True,
                'image_url': image_url
            })
        except Exception as img_error:
            print(f"خطأ في توليد الصورة من DALL-E: {str(img_error)}", file=sys.stderr)
            raise Exception(f"فشل في توليد الصورة: {str(img_error)}")
        
    except Exception as e:
        error_msg = str(e)
        print(f"خطأ في توليد الصورة: {error_msg}", file=sys.stderr)
        print("تفاصيل الخطأ الكاملة:", file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        
        if "API key" in error_msg.lower():
            error_msg = "خطأ في مفتاح API. الرجاء التحقق من صحة المفتاح"
        elif "billing" in error_msg.lower():
            error_msg = "خطأ في الفوترة. الرجاء التحقق من حالة حسابك"
        
        return jsonify({
            'success': False,
            'error': error_msg
        })

if __name__ == '__main__':
    app.run(debug=True)
